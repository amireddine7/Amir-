import { Instagram, Send, MapPin, Mail, Phone, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black text-white pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div>
            <h3 className="text-3xl font-bold mb-4 tracking-wider">
              MIRO STYLE
            </h3>
            <div className="h-1 w-16 bg-amber-400 mb-6" />
            <p className="text-gray-400 leading-relaxed mb-4">
              Luxury streetwear for those who dare to be different. Premium quality, bold designs.
            </p>
            <p className="text-amber-400 text-sm" dir="rtl">
              أزياء فاخرة لمن يجرؤ على التميز
            </p>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 tracking-wider">SHOP</h4>
            <ul className="space-y-3">
              {['Men Collection', 'Women Collection', 'New Arrivals', 'Streetwear', 'Accessories', 'Sale'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors duration-300 flex items-center group">
                    <span className="w-0 group-hover:w-2 h-0.5 bg-amber-400 mr-0 group-hover:mr-2 transition-all duration-300" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 tracking-wider">SUPPORT</h4>
            <ul className="space-y-3">
              {['Contact Us', 'Shipping Info', 'Returns & Exchange', 'Size Guide', 'FAQ', 'Track Order'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors duration-300 flex items-center group">
                    <span className="w-0 group-hover:w-2 h-0.5 bg-amber-400 mr-0 group-hover:mr-2 transition-all duration-300" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 tracking-wider">CONTACT</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3 text-gray-400 hover:text-amber-400 transition-colors duration-300">
                <MapPin className="w-5 h-5 mt-1 flex-shrink-0" />
                <p className="text-sm">123 Fashion Avenue, Paris, France</p>
              </div>
              <div className="flex items-center gap-3 text-gray-400 hover:text-amber-400 transition-colors duration-300">
                <Mail className="w-5 h-5 flex-shrink-0" />
                <p className="text-sm">contact@mirostyle.com</p>
              </div>
              <div className="flex items-center gap-3 text-gray-400 hover:text-amber-400 transition-colors duration-300">
                <Phone className="w-5 h-5 flex-shrink-0" />
                <p className="text-sm">+33 1 23 45 67 89</p>
              </div>
            </div>

            <div className="mt-8">
              <h5 className="text-sm font-bold mb-4 tracking-wider">FOLLOW US</h5>
              <div className="flex gap-4">
                {[
                  { Icon: Instagram, href: '#' },
                  { Icon: Facebook, href: '#' },
                  { Icon: Send, href: '#' }
                ].map(({ Icon, href }, index) => (
                  <a
                    key={index}
                    href={href}
                    className="p-3 bg-white/5 hover:bg-amber-400 border border-white/10 hover:border-amber-400 transition-all duration-300 group"
                  >
                    <Icon className="w-5 h-5 text-gray-400 group-hover:text-black transition-colors duration-300" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © 2024 MIRO STYLE. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors duration-300">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors duration-300">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors duration-300">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
