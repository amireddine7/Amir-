export default function BrandStory() {
  return (
    <section className="relative py-32 overflow-hidden">
      <div
        className="absolute inset-0 bg-fixed bg-cover bg-center"
        style={{
          backgroundImage: "url('https://images.pexels.com/photos/1126993/pexels-photo-1126993.jpeg?auto=compress&cs=tinysrgb&w=1920')",
        }}
      >
        <div className="absolute inset-0 bg-black/80" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
        <div className="mb-8">
          <h2 className="text-6xl md:text-7xl font-bold text-white mb-6 tracking-wider">
            THE MIRO LEGACY
          </h2>
          <div className="h-1 w-32 bg-gradient-to-r from-transparent via-amber-400 to-transparent mx-auto mb-8" />
        </div>

        <div className="space-y-8 text-white">
          <p className="text-2xl md:text-3xl font-light leading-relaxed">
            At <span className="text-amber-400 font-bold">MIRO STYLE</span>,
            fashion meets attitude
          </p>

          <p className="text-xl md:text-2xl text-gray-300 leading-relaxed" dir="rtl">
            في ميرو ستايل، الموضة تلتقي بالأسلوب
          </p>

          <div className="my-12 py-8 border-t border-b border-amber-400/30">
            <p className="text-lg md:text-xl text-gray-200 leading-relaxed max-w-3xl mx-auto">
              Premium quality for those who <span className="text-amber-400 font-semibold">dare to stand out</span>.
              We blend timeless elegance with contemporary streetwear,
              crafting pieces that define your bold identity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 hover:border-amber-400/50 transition-all duration-500 hover:transform hover:scale-105">
              <h3 className="text-3xl font-bold text-amber-400 mb-2">100+</h3>
              <p className="text-gray-300 tracking-wide">Exclusive Designs</p>
            </div>
            <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 hover:border-amber-400/50 transition-all duration-500 hover:transform hover:scale-105">
              <h3 className="text-3xl font-bold text-amber-400 mb-2">50K+</h3>
              <p className="text-gray-300 tracking-wide">Global Community</p>
            </div>
            <div className="p-6 bg-white/5 backdrop-blur-sm border border-white/10 hover:border-amber-400/50 transition-all duration-500 hover:transform hover:scale-105">
              <h3 className="text-3xl font-bold text-amber-400 mb-2">15+</h3>
              <p className="text-gray-300 tracking-wide">Countries Worldwide</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
