import { ShoppingCart, Heart } from 'lucide-react';
import { useState } from 'react';

const products = [
  {
    id: 1,
    name: 'Luxury Leather Jacket',
    nameAr: 'جاكيت جلد فاخر',
    price: 899,
    image: 'https://images.pexels.com/photos/1124468/pexels-photo-1124468.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Men'
  },
  {
    id: 2,
    name: 'Designer Tracksuit',
    nameAr: 'بدلة رياضية مصممة',
    price: 649,
    image: 'https://images.pexels.com/photos/1346187/pexels-photo-1346187.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Men'
  },
  {
    id: 3,
    name: 'Premium Silk Dress',
    nameAr: 'فستان حرير فاخر',
    price: 1299,
    image: 'https://images.pexels.com/photos/1926620/pexels-photo-1926620.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Women'
  },
  {
    id: 4,
    name: 'Tailored Suit',
    nameAr: 'بدلة رسمية',
    price: 1499,
    image: 'https://images.pexels.com/photos/1040424/pexels-photo-1040424.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Men'
  },
  {
    id: 5,
    name: 'Oversized Hoodie',
    nameAr: 'هودي واسع',
    price: 449,
    image: 'https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Streetwear'
  },
  {
    id: 6,
    name: 'Elegant Cardigan',
    nameAr: 'كارديجان أنيق',
    price: 549,
    image: 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Women'
  },
  {
    id: 7,
    name: 'Gold Chain Necklace',
    nameAr: 'قلادة ذهبية',
    price: 799,
    image: 'https://images.pexels.com/photos/1413420/pexels-photo-1413420.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Accessories'
  },
  {
    id: 8,
    name: 'Designer Jeans',
    nameAr: 'جينز مصمم',
    price: 399,
    image: 'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Men'
  }
];

export default function FeaturedProducts() {
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold text-black mb-4 tracking-wider">
            FEATURED COLLECTION
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-transparent via-amber-400 to-transparent mx-auto mb-4" />
          <p className="text-xl text-gray-600 font-light" dir="rtl">
            قطع مختارة بعناية لك
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="group relative bg-black overflow-hidden cursor-pointer transform transition-all duration-500 hover:scale-105 hover:shadow-2xl"
              onMouseEnter={() => setHoveredId(product.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              <div className="relative h-96 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />

                <div className="absolute top-4 right-4">
                  <button className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-amber-400 transition-colors duration-300">
                    <Heart className="w-5 h-5 text-white" />
                  </button>
                </div>

                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-amber-400 text-black text-xs font-bold tracking-wider">
                    {product.category}
                  </span>
                </div>
              </div>

              <div className="p-6 bg-black text-white">
                <h3 className="text-xl font-bold mb-1 tracking-wide">
                  {product.name}
                </h3>
                <p className="text-sm text-amber-400 mb-3 font-light" dir="rtl">
                  {product.nameAr}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-amber-400">
                    ${product.price}
                  </span>
                  <button
                    className={`flex items-center gap-2 px-4 py-2 bg-white text-black font-semibold text-sm tracking-wider transition-all duration-300 ${
                      hoveredId === product.id ? 'translate-x-0 opacity-100' : 'translate-x-4 opacity-0'
                    } hover:bg-amber-400`}
                  >
                    <ShoppingCart className="w-4 h-4" />
                    ADD
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
