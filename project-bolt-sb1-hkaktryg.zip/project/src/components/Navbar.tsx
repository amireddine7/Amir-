import { ShoppingBag, Menu, X, Search, Heart, User } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-500 ${
        isScrolled ? 'bg-black/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-8">
            <a href="#" className="text-2xl md:text-3xl font-bold text-white tracking-wider hover:text-amber-400 transition-colors duration-300">
              MIRO STYLE
            </a>
            <div className="hidden lg:flex items-center gap-6">
              {['Men', 'Women', 'New Arrivals', 'Streetwear', 'Accessories'].map((item) => (
                <a
                  key={item}
                  href="#"
                  className="text-sm text-white/80 hover:text-amber-400 font-medium tracking-wider transition-colors duration-300 relative group"
                >
                  {item}
                  <span className="absolute bottom-[-4px] left-0 w-0 h-0.5 bg-amber-400 group-hover:w-full transition-all duration-300" />
                </a>
              ))}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <button className="text-white hover:text-amber-400 transition-colors duration-300">
              <Search className="w-5 h-5" />
            </button>
            <button className="text-white hover:text-amber-400 transition-colors duration-300">
              <User className="w-5 h-5" />
            </button>
            <button className="text-white hover:text-amber-400 transition-colors duration-300 relative">
              <Heart className="w-5 h-5" />
              <span className="absolute -top-2 -right-2 w-4 h-4 bg-amber-400 text-black text-xs rounded-full flex items-center justify-center font-bold">
                3
              </span>
            </button>
            <button className="text-white hover:text-amber-400 transition-colors duration-300 relative">
              <ShoppingBag className="w-5 h-5" />
              <span className="absolute -top-2 -right-2 w-4 h-4 bg-amber-400 text-black text-xs rounded-full flex items-center justify-center font-bold">
                2
              </span>
            </button>
          </div>

          <button
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-black/95 backdrop-blur-md border-t border-white/10 animate-fade-in">
          <div className="px-4 py-6 space-y-4">
            {['Men', 'Women', 'New Arrivals', 'Streetwear', 'Accessories'].map((item) => (
              <a
                key={item}
                href="#"
                className="block text-white hover:text-amber-400 font-medium tracking-wider transition-colors duration-300 py-2"
              >
                {item}
              </a>
            ))}
            <div className="flex items-center gap-6 pt-4 border-t border-white/10">
              <button className="text-white hover:text-amber-400 transition-colors duration-300">
                <Search className="w-5 h-5" />
              </button>
              <button className="text-white hover:text-amber-400 transition-colors duration-300">
                <User className="w-5 h-5" />
              </button>
              <button className="text-white hover:text-amber-400 transition-colors duration-300 relative">
                <Heart className="w-5 h-5" />
                <span className="absolute -top-2 -right-2 w-4 h-4 bg-amber-400 text-black text-xs rounded-full flex items-center justify-center font-bold">
                  3
                </span>
              </button>
              <button className="text-white hover:text-amber-400 transition-colors duration-300 relative">
                <ShoppingBag className="w-5 h-5" />
                <span className="absolute -top-2 -right-2 w-4 h-4 bg-amber-400 text-black text-xs rounded-full flex items-center justify-center font-bold">
                  2
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
