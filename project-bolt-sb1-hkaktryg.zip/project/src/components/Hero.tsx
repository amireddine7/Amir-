import { ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative h-screen w-full overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg?auto=compress&cs=tinysrgb&w=1920')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80" />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
        <div className="animate-fade-in">
          <h1 className="text-6xl md:text-8xl font-bold text-white mb-4 tracking-wider">
            MIRO STYLE
          </h1>
          <div className="h-1 w-32 bg-gradient-to-r from-transparent via-amber-400 to-transparent mx-auto mb-6" />
          <p className="text-xl md:text-3xl text-amber-400 font-light mb-2 tracking-wide">
            Be Bold. Be Miro.
          </p>
          <p className="text-lg md:text-xl text-white/90 font-light mb-8 tracking-wide" dir="rtl">
            الأناقة تبدأ من التفاصيل
          </p>
          <button className="group relative px-12 py-4 bg-white text-black font-semibold text-lg tracking-wider overflow-hidden transition-all duration-500 hover:scale-105">
            <span className="relative z-10 group-hover:text-white transition-colors duration-500">
              SHOP COLLECTION
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-600 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
          </button>
        </div>

        <div className="absolute bottom-10 animate-bounce">
          <ChevronDown className="w-8 h-8 text-amber-400" />
        </div>
      </div>
    </section>
  );
}
