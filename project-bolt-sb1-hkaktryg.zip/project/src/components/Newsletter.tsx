import { Mail, Gift } from 'lucide-react';
import { useState } from 'react';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setEmail('');
    }, 3000);
  };

  return (
    <section className="py-24 bg-gradient-to-br from-black via-zinc-900 to-black">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <div className="mb-8">
          <Gift className="w-16 h-16 text-amber-400 mx-auto mb-6 animate-pulse" />
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-4 tracking-wider">
            JOIN THE MIRO CLUB
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-transparent via-amber-400 to-transparent mx-auto mb-6" />
          <p className="text-xl text-gray-300 mb-2">
            Exclusive offers, style tips, and early access to new collections
          </p>
          <p className="text-lg text-amber-400 font-light" dir="rtl">
            عروض حصرية ووصول مبكر للمجموعات الجديدة
          </p>
        </div>

        {isSubmitted ? (
          <div className="py-12 animate-fade-in">
            <div className="inline-block p-6 bg-amber-400/10 border-2 border-amber-400 rounded-lg">
              <p className="text-2xl text-amber-400 font-semibold mb-2">
                Welcome to the Club!
              </p>
              <p className="text-gray-300">
                Check your inbox for exclusive perks
              </p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto mt-12">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-amber-400 transition-colors duration-300" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-white/5 border-2 border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-amber-400 transition-all duration-300 backdrop-blur-sm"
                />
              </div>
              <button
                type="submit"
                className="group relative px-8 py-4 bg-amber-400 text-black font-bold tracking-wider overflow-hidden hover:shadow-lg hover:shadow-amber-400/50 transition-all duration-300"
              >
                <span className="relative z-10">SUBSCRIBE</span>
                <div className="absolute inset-0 bg-white transform translate-x-full group-hover:translate-x-0 transition-transform duration-500" />
              </button>
            </div>
            <p className="mt-4 text-sm text-gray-400">
              By subscribing, you agree to our Privacy Policy
            </p>
          </form>
        )}

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-left">
          {['Free Shipping', 'Early Access', '10% Off First Order', 'Style Insider'].map((benefit, index) => (
            <div key={index} className="p-4 bg-white/5 backdrop-blur-sm border border-white/10 hover:border-amber-400/50 transition-all duration-300">
              <div className="w-2 h-2 bg-amber-400 rounded-full mb-2" />
              <p className="text-white font-medium text-sm">{benefit}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
