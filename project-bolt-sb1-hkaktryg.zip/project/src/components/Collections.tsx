import { Users, Heart, Sparkles, Watch, Star } from 'lucide-react';

const collections = [
  {
    id: 1,
    title: 'Men',
    titleAr: 'رجال',
    icon: Users,
    image: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-slate-900 to-slate-700'
  },
  {
    id: 2,
    title: 'Women',
    titleAr: 'نساء',
    icon: Heart,
    image: 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-amber-900 to-amber-700'
  },
  {
    id: 3,
    title: 'New Arrivals',
    titleAr: 'وصل حديثاً',
    icon: Star,
    image: 'https://images.pexels.com/photos/1549200/pexels-photo-1549200.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-stone-900 to-stone-700'
  },
  {
    id: 4,
    title: 'Streetwear',
    titleAr: 'ستريت وير',
    icon: Sparkles,
    image: 'https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-zinc-900 to-zinc-700'
  },
  {
    id: 5,
    title: 'Accessories',
    titleAr: 'إكسسوارات',
    icon: Watch,
    image: 'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-neutral-900 to-neutral-700'
  }
];

export default function Collections() {
  return (
    <section className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-4 tracking-wider">
            COLLECTIONS
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-transparent via-amber-400 to-transparent mx-auto" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {collections.map((collection) => {
            const Icon = collection.icon;
            return (
              <div
                key={collection.id}
                className="group relative h-96 overflow-hidden cursor-pointer"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                  style={{ backgroundImage: `url('${collection.image}')` }}
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${collection.gradient} opacity-60 group-hover:opacity-40 transition-opacity duration-500`} />

                <div className="relative h-full flex flex-col items-center justify-center text-white p-6">
                  <Icon className="w-12 h-12 mb-4 text-amber-400 transform group-hover:scale-125 group-hover:rotate-12 transition-all duration-500" />
                  <h3 className="text-3xl font-bold mb-2 tracking-wider transform group-hover:translate-y-[-10px] transition-transform duration-500">
                    {collection.title}
                  </h3>
                  <p className="text-lg text-amber-400 font-light" dir="rtl">
                    {collection.titleAr}
                  </p>
                  <div className="mt-6 opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                    <span className="inline-block border-2 border-white px-6 py-2 text-sm tracking-widest hover:bg-white hover:text-black transition-colors duration-300">
                      EXPLORE
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
